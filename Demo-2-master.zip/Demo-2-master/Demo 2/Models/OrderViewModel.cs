﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace Demo_2.Models
{
    public class OrderViewModel
    {
        public int OrderId { get; set; }
        public int Quantity { get; set; }
        public int MenuItemId { get; set; }
        public List<SelectListItem> MenuItems { get; set; }
    }
}
