﻿namespace Demo_2.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int Quantity { get; set; }
        public DateOnly OrderDate { get; set; }
        public int MenuItemId { get; set; }
        public MenuItem MenuItem { get; set; }

    }
}
