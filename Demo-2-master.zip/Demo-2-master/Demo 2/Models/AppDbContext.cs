﻿using Microsoft.EntityFrameworkCore;

namespace Demo_2.Models
{
    public class AppDbContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<MenuItem> MenuItems { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MIT;Initial Catalog=\"Demo 2\";Integrated Security=True");
        }
    }
}
