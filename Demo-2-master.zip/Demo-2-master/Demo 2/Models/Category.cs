﻿namespace Demo_2.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public List<MenuItem> MenuItems { get; set; }
    }
}
