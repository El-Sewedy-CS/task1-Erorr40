﻿using Demo_2.Models;
using Demo_2.Repo.Interface;

namespace Demo_2.Repo
{
    public class CategoryRepo : ICategory
    {
        AppDbContext _db;
        public CategoryRepo(AppDbContext db)
        {
            _db = db;
        }
        public void Add(Category category)
        {
            _db.Categories.Add(category);
            _db.SaveChanges();
        }

        public void Delete(int id)
        {
            _db.Categories.Remove(GetById(id));
            _db.SaveChanges();
        }

        public List<Category> GetAll()
        {
             _db.Categories.ToList();
             return _db.Categories.ToList();
        }

        public Category GetById(int id)
        {
            var f = _db.Categories.Find(id);
            return f;
        }

        public void Update(Category category)
        {
            _db.Categories.Update(category);
            _db.SaveChanges();
        }
    }
}
