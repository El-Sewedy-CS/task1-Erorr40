﻿using Demo_2.Models;
using Demo_2.Repo.Interface;

namespace Demo_2.Repo
{
    public class MenuItemRepo : IMenuItem
    {
        AppDbContext _db;
        public MenuItemRepo(AppDbContext db)
        {
            _db = db;
        }
        public void AddItem(MenuItem menuItem)
        {
            _db.MenuItems.Add(menuItem);
            _db.SaveChanges();
        }

        public void DeleteItem(int id)
        {
            _db.MenuItems.Remove(GetItemById(id));
            _db.SaveChanges();
        }
        

        public List<MenuItem> GetAllItems()
        {
            return _db.MenuItems.ToList();
        }

        public MenuItem GetItemById(int id)
        {
            return _db.MenuItems.Find(id);
        }

        public void UpdateItem(MenuItem menuItem)
        {
            _db.MenuItems.Update(menuItem);
            _db.SaveChanges();
        }
    }
}
