﻿using Demo_2.Models;
using Demo_2.Repo.Interface;

namespace Demo_2.Repo
{
    public class OrderRepo : IOrder
    {
        AppDbContext _db;
        public OrderRepo(AppDbContext db)
        {
            _db = db;
        }
        public void AddOrder(Order order)
        {
            _db.Orders.Add(order);
            _db.SaveChanges();
        }

        public void DeleteOrder(int id)
        {
            _db.Orders.Remove(GetById(id));
            _db.SaveChanges();
        }

        public List<Order> GetAllOrders()
        {
            return _db.Orders.ToList();
        }

        public Order GetById(int id)
        {
            return _db.Orders.Find(id);
        }

        public void UpdateOrder(Order order)
        {
            _db.Orders.Update(order);
            _db.SaveChanges();
        }
    }
}
