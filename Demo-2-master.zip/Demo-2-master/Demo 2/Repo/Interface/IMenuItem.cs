﻿using Demo_2.Models;

namespace Demo_2.Repo.Interface
{
    public interface IMenuItem
    {
        public List<MenuItem> GetAllItems();
        public MenuItem GetItemById(int id);
        public void AddItem(MenuItem menuItem);
        public void UpdateItem(MenuItem menuItem);
        public void DeleteItem(int id);
    }
}
