﻿using Demo_2.Models;

namespace Demo_2.Repo.Interface
{
    public interface IOrder
    {
        public List<Order> GetAllOrders();
        public Order GetById(int id);
        public void AddOrder(Order order);
        public void UpdateOrder(Order order);
        public void DeleteOrder(int id);
    }
}
