﻿using Demo_2.Models;

namespace Demo_2.Repo.Interface
{
    public interface ICategory
    {
        public List<Category> GetAll();
         public Category GetById(int id);
         public void Add(Category category);
         public void Update(Category category);
         public void Delete(int id);
    }
}
