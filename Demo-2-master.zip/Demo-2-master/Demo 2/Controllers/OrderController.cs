﻿using Demo_2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Demo_2.Controllers
{
    public class OrderController : Controller
    {
        private readonly AppDbContext _db;

        public OrderController(AppDbContext db)
        {
            _db = db;
        }

        // GET: OrderController
        public ActionResult Index()
        {
            var orders = _db.Orders.Include(o => o.MenuItem).ToList();
            return View(orders);
        }

        // GET: OrderController/Details/5
        public ActionResult Details(int id)
        {
            var order = _db.Orders.Include(o => o.MenuItem).First(o => o.Id == id);
            return View(order);
        }

        // GET: OrderController/Create
        public ActionResult Create()
        {
            var model = new OrderViewModel
            {
                MenuItems = _db.MenuItems
                    .Select(m => new SelectListItem
                    {
                        Value = m.Id.ToString(),
                        Text = m.Name
                    })
                    .ToList()
            };

            return View(model);
        }

        // POST: OrderController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(OrderViewModel model)
        {
            var order = new Order
            {
                Quantity = model.Quantity,
                MenuItemId = model.MenuItemId,
                OrderDate = DateOnly.FromDateTime(DateTime.Now)
            };

            _db.Orders.Add(order);
            _db.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        // GET: OrderController/Edit/5
        public ActionResult Edit(int id)
        {
            var order = _db.Orders.First(o => o.Id == id);
            return View(order);
        }

        // POST: OrderController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Order order)
        {
            order.Id = id;
            _db.Orders.Update(order);
            _db.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        // GET: OrderController/Delete/5
        public ActionResult Delete(int id)
        {
            var order = _db.Orders.Include(o => o.MenuItem).First(o => o.Id == id);
            return View(order);
        }

        // POST: OrderController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var order = _db.Orders.First(o => o.Id == id);
            _db.Orders.Remove(order);
            _db.SaveChanges();

            return RedirectToAction(nameof(Index));
        }
    }
}
