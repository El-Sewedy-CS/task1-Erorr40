﻿using Demo_2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Demo_2.Controllers
{
    public class MenuItemController : Controller
    {
        private readonly AppDbContext _db;

        public MenuItemController(AppDbContext db)
        {
            _db = db;
        }

        private void LoadCategories(int selectedCategoryId = 0)
        {
            ViewBag.CategoryId = new SelectList(
                _db.Categories.ToList(),
                "CategoryId",
                "CategoryName",
                selectedCategoryId
            );
        }

        // GET: MenuItemController
        public ActionResult Index()
        {
            var menuItems = _db.MenuItems.Include(m => m.Category).ToList();
            return View(menuItems);
        }

        // GET: MenuItemController/Details/5
        public ActionResult Details(int id)
        {
            var menuItem = _db.MenuItems.Include(m => m.Category).First(m => m.Id == id);
            return View(menuItem);
        }

        // GET: MenuItemController/Create
        public ActionResult Create()
        {
            LoadCategories();
            return View();
        }

        // POST: MenuItemController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(MenuItem menuItem)
        {
            _db.MenuItems.Add(menuItem);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // GET: MenuItemController/Edit/5
        public ActionResult Edit(int id)
        {
            var menuItem = _db.MenuItems.First(m => m.Id == id);
            LoadCategories(menuItem.CategoryId);
            return View(menuItem);
        }

        // POST: MenuItemController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, MenuItem menuItem)
        {
            menuItem.Id = id;
            _db.MenuItems.Update(menuItem);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // GET: MenuItemController/Delete/5
        public ActionResult Delete(int id)
        {
            var menuItem = _db.MenuItems.Include(m => m.Category).First(m => m.Id == id);
            return View(menuItem);
        }

        // POST: MenuItemController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var menuItem = _db.MenuItems.First(m => m.Id == id);
            _db.MenuItems.Remove(menuItem);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}
